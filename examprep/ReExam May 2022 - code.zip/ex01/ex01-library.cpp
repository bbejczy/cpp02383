#include <iostream>
#include "ex01-library.h"

using namespace std;

// Task 1(a).  Implement this function
Square **createChessboard(unsigned int m, unsigned int n) {
    // Replace the following with your code
    return nullptr;
}

// Task 1(b).  Implement this function
void displayChessboard(Square **c,
                       unsigned int m, unsigned int n) {
    // Write your code here
}

// Task 1(c).  Implement this function
bool move(Square **c, unsigned int m, unsigned int n,
          int r1, int c1, int r2, int c2) {
    // Replace the following with your code
    return false;
}

// Task 1(d).  Implement this function
bool threatened(Square **c, unsigned int m, unsigned int n,
                int row, int col) {
    // Replace the following with your code
    return false;
}

// Do not modify
void deleteChessboard(Square **c, unsigned int m) {
    for (unsigned int i = 0; i < m; i++) {
        delete[] c[i];
    }
    delete[] c;
}
