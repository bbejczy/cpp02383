#include <iostream>
#include "ex02-library.h"
using namespace std;

// Task 2(a).  Implement this function
Elem* reverse(Elem *list) {
    // Write your code here
}

// Task 2(b).  Implement this function
Elem* concatenate(Elem *list1, Elem *list2) {
    // Write your code here
}

// Task 2(c).  Implement this function
int sum(Elem *list) {
    // Write your code here
}

// Do not modify
void displayRLEList(Elem *list) {
    if (list == nullptr) {
        return;
    }
    cout << " " << list->value << " (x" << list->times << ")";
    displayRLEList(list->next);
}
